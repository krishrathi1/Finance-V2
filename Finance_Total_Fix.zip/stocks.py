import asyncio
from datetime import datetime, timedelta, timezone
import hashlib
import json
import re

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from app.core.cache import redis_cache
from app.core.config import get_settings
from app.schemas.stock import ChatRequest, ChatResponse, CompareAnalysisRequest, NewsAnalysisRequest, NewsAnalysisResponse, ReportResponse
from app.services.ai_adapter import AIAdapter
from app.services.dashboard import StockDashboardService
from app.services.sample_data import get_sample_dashboard


router = APIRouter(prefix="/stocks", tags=["stocks"])
settings = get_settings()
dashboard_service = StockDashboardService()
ai_adapter = AIAdapter()
IST = timezone(timedelta(hours=5, minutes=30))


async def _refresh_market_news_cache(today: str, cache_key: str, stale_key: str) -> None:
    try:
        data = await dashboard_service.get_market_news()
        if data:
            payload = {"date": today, "items": data, "fetchedAt": datetime.now(IST).isoformat()}
            await redis_cache.set_json(cache_key, payload, ttl_seconds=60 * 60 * 30)
            await redis_cache.set_json(stale_key, payload, ttl_seconds=60 * 60 * 24 * 7)
    except Exception:
        return


async def _refresh_dashboard_cache(symbol: str, timeframe: str, cache_key: str, stale_key: str, exchange: str = "NSE") -> None:
    try:
        data = await asyncio.wait_for(dashboard_service.get_dashboard(symbol=symbol, timeframe=timeframe, exchange=exchange), timeout=55)
        data = await _enrich_score_explanations(symbol=symbol, data=data, allow_gemini=True)
        await redis_cache.set_json(cache_key, data, ttl_seconds=settings.cache_ttl_seconds)
        await redis_cache.set_json(stale_key, data, ttl_seconds=60 * 60 * 24 * 7)
    except Exception:
        return


async def _enrich_score_explanations(symbol: str, data: dict, allow_gemini: bool = True) -> dict:
    data = await _enrich_profile_details(symbol=symbol, data=data, allow_gemini=allow_gemini)
    data = await _enrich_smart_score_explanation(symbol=symbol, data=data, allow_gemini=allow_gemini)
    data = await _enrich_risk_score_explanation(symbol=symbol, data=data, allow_gemini=allow_gemini)
    return data


def _dashboard_needs_ai_refresh(data: dict) -> bool:
    if not isinstance(data, dict):
        return False

    profile = data.get("profile") if isinstance(data.get("profile"), dict) else {}
    smart = data.get("smartScore") if isinstance(data.get("smartScore"), dict) else {}
    risk = data.get("riskScore") if isinstance(data.get("riskScore"), dict) else {}

    profile_missing = (
        not profile.get("incorporationYear")
        or not str(profile.get("headquarters") or "").strip()
        or str(profile.get("chairman") or "").strip() in {"", "N/A"}
        or str(profile.get("previousName") or "").strip() in {"", "N/A"}
    )
    smart_missing = not str(smart.get("aiExplanation") or "").strip() or str(smart.get("aiSource") or "").strip().lower() != "gemini"
    risk_missing = not str(risk.get("aiExplanation") or "").strip() or str(risk.get("aiSource") or "").strip().lower() != "gemini"
    return profile_missing or smart_missing or risk_missing


async def _enrich_profile_details(symbol: str, data: dict, allow_gemini: bool = True) -> dict:
    if not isinstance(data, dict):
        return data

    profile = data.get("profile")
    if not isinstance(profile, dict):
        return data

    changed = False

    description = str(profile.get("description") or "").strip()
    if (not profile.get("incorporationYear")) and description:
        match = re.search(r"\bincorporated in (\d{4})\b", description, flags=re.IGNORECASE)
        if match:
            try:
                profile["incorporationYear"] = int(match.group(1))
                changed = True
            except Exception:
                pass

    if not str(profile.get("headquarters") or "").strip() and description:
        match = re.search(r"\bheadquartered in ([A-Za-z ,.-]+?)(?:\.|, and| and is| with|$)", description, flags=re.IGNORECASE)
        if match:
            headquarters = " ".join(match.group(1).split()).strip(" ,.")
            if headquarters:
                profile["headquarters"] = headquarters
                changed = True

    needs_ai = (
        not profile.get("incorporationYear")
        or not str(profile.get("headquarters") or "").strip()
        or str(profile.get("chairman") or "").strip() in {"", "N/A"}
        or str(profile.get("previousName") or "").strip() in {"", "N/A"}
    )

    if needs_ai and allow_gemini and bool(str(settings.gemini_api_key or "").strip()):
        try:
            raw = await asyncio.wait_for(ai_adapter.extract_profile_details(symbol=symbol, context=data), timeout=12)
            parsed = _parse_profile_json(raw)
            year_value = parsed.get("incorporationYear")
            if not profile.get("incorporationYear") and isinstance(year_value, int) and 1800 <= year_value <= datetime.now().year:
                profile["incorporationYear"] = year_value
                changed = True

            headquarters_value = str(parsed.get("headquarters") or "").strip()
            if not str(profile.get("headquarters") or "").strip() and headquarters_value:
                profile["headquarters"] = headquarters_value
                changed = True

            chairman_value = str(parsed.get("chairman") or "").strip()
            if str(profile.get("chairman") or "").strip() in {"", "N/A"} and chairman_value:
                profile["chairman"] = chairman_value
                changed = True

            previous_name_value = str(parsed.get("previousName") or "").strip()
            if str(profile.get("previousName") or "").strip() in {"", "N/A"} and previous_name_value:
                profile["previousName"] = previous_name_value
                changed = True
        except Exception:
            pass

    if not str(profile.get("chairman") or "").strip():
        profile["chairman"] = "N/A"
    if not str(profile.get("previousName") or "").strip():
        profile["previousName"] = "N/A"

    if changed:
        data["profile"] = profile
    return data


def _parse_profile_json(raw: str) -> dict:
    text = str(raw or "").strip()
    if not text:
        return {}
    fenced = re.search(r"\{.*\}", text, flags=re.DOTALL)
    candidate = fenced.group(0) if fenced else text
    try:
        parsed = json.loads(candidate)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


async def _enrich_smart_score_explanation(symbol: str, data: dict, allow_gemini: bool = True) -> dict:
    smart = data.get("smartScore") if isinstance(data, dict) else None
    if not isinstance(smart, dict):
        return data

    methodology = (
        "Factor score uses normalized profitability, growth, valuation, momentum, and balance-sheet health. "
        "A bounded walk-forward ML signal validates trend persistence before applying a small score adjustment."
    )
    smart["methodology"] = smart.get("methodology") or methodology
    dims = smart.get("dimensions") if isinstance(smart.get("dimensions"), dict) else {}
    weak_hint = None
    if dims:
        weakest = sorted(dims.items(), key=lambda item: float(item[1]))[0][0]
        weak_hint = str(weakest)

    gemini_enabled = bool(str(settings.gemini_api_key or "").strip())
    ai_explanation = str(smart.get("aiExplanation") or "").strip()
    ai_source = str(smart.get("aiSource") or "").strip().lower()

    # If Gemini is now enabled, refresh non-Gemini (or missing) explanations once and cache them.
    if allow_gemini and gemini_enabled and (not ai_explanation or ai_source != "gemini"):
        try:
            generated = await asyncio.wait_for(ai_adapter.explain_smart_score(symbol=symbol, context=data), timeout=12)
            if generated and str(generated).strip():
                smart["aiExplanation"] = _to_plain_language_ai_text(
                    symbol=symbol,
                    score=float(smart.get("score", 0.0) or 0.0),
                    label=str(smart.get("label") or "Moderate"),
                    text=str(generated).strip(),
                    weak_hint=weak_hint,
                )
                smart["aiSource"] = "gemini"
                return data
        except Exception:
            pass

    if ai_explanation:
        smart["aiExplanation"] = _to_plain_language_ai_text(
            symbol=symbol,
            score=float(smart.get("score", 0.0) or 0.0),
            label=str(smart.get("label") or "Moderate"),
            text=ai_explanation,
            weak_hint=weak_hint,
        )
        if ai_source not in {"gemini", "fallback"}:
            smart["aiSource"] = "fallback"
        return data

    score_value = float(smart.get("score", 0.0) or 0.0)
    label = str(smart.get("label") or "Moderate")
    smart["aiExplanation"] = _to_plain_language_ai_text(
        symbol=symbol,
        score=score_value,
        label=label,
        text=(
            f"{symbol.upper()} has a Smart Score of {score_value:.1f} out of 5 ({label}). "
            "Some parts are good, but some parts are weak right now, so it is better to invest slowly."
        ),
        weak_hint=weak_hint,
    )
    smart["aiSource"] = "fallback"
    return data


def _to_plain_language_ai_text(symbol: str, score: float, label: str, text: str, weak_hint: str | None = None) -> str:
    simplified = " ".join(str(text or "").split())
    replacements = {
        r"\bsetup\b": "overall picture",
        r"\bposition sizing\b": "how much money to put",
        r"\ballocation\b": "money split",
        r"\bconviction\b": "confidence",
        r"\bdrawdown\b": "price fall",
        r"\bvolatility\b": "price ups and downs",
        r"\bmomentum\b": "recent price trend",
        r"\bprofitability\b": "profit strength",
        r"\bfinancialHealth\b": "financial safety",
        r"\bfinancial health\b": "financial safety",
        r"\bneutral setup\b": "middle rating",
        r"\bbullish\b": "positive",
        r"\bbearish\b": "weak",
    }
    for pattern, target in replacements.items():
        simplified = re.sub(pattern, target, simplified, flags=re.IGNORECASE)

    if "smart score" not in simplified.lower():
        simplified = (
            f"{symbol.upper()} has a Smart Score of {score:.1f} out of 5 ({label}). "
            f"{simplified}"
        ).strip()

    # Keep text short and easy to scan in the UI.
    if len(simplified) > 220:
        chunks = re.split(r"(?<=[.!?])\s+", simplified)
        simplified = " ".join(chunks[:2]).strip()
    if not re.search(r"\b(weak|caution|careful|risk|go slowly|invest slowly|watch)\b", simplified, flags=re.IGNORECASE):
        hint = (weak_hint or "momentum").replace("financialHealth", "financial safety")
        hint = hint.replace("momentum", "recent price trend").replace("profitability", "profit strength")
        base = simplified.strip()
        if base and base[-1] not in ".!?":
            base += "."
        simplified = f"{base} The weak part right now is {hint}, so invest slowly."
    return simplified


async def _enrich_risk_score_explanation(symbol: str, data: dict, allow_gemini: bool = True) -> dict:
    risk = data.get("riskScore") if isinstance(data, dict) else None
    if not isinstance(risk, dict):
        return data

    methodology = (
        "Risk score combines market mood, company financial stress, negative news signals, and price instability."
    )
    risk["methodology"] = risk.get("methodology") or methodology

    components = risk.get("components") if isinstance(risk.get("components"), dict) else {}
    high_hint = None
    if components:
        highest = sorted(components.items(), key=lambda item: float(item[1]), reverse=True)[0][0]
        high_hint = str(highest)

    gemini_enabled = bool(str(settings.gemini_api_key or "").strip())
    ai_explanation = str(risk.get("aiExplanation") or "").strip()
    ai_source = str(risk.get("aiSource") or "").strip().lower()

    # If Gemini is now enabled, refresh non-Gemini (or missing) explanations once and cache them.
    if allow_gemini and gemini_enabled and (not ai_explanation or ai_source != "gemini"):
        try:
            generated = await asyncio.wait_for(ai_adapter.explain_risk_score(symbol=symbol, context=data), timeout=12)
            if generated and str(generated).strip():
                risk["aiExplanation"] = _to_plain_language_risk_text(
                    symbol=symbol,
                    score=float(risk.get("score", 0.0) or 0.0),
                    label=str(risk.get("label") or "Medium"),
                    text=str(generated).strip(),
                    high_hint=high_hint,
                )
                risk["aiSource"] = "gemini"
                return data
        except Exception:
            pass

    if ai_explanation:
        risk["aiExplanation"] = _to_plain_language_risk_text(
            symbol=symbol,
            score=float(risk.get("score", 0.0) or 0.0),
            label=str(risk.get("label") or "Medium"),
            text=ai_explanation,
            high_hint=high_hint,
        )
        if ai_source not in {"gemini", "fallback"}:
            risk["aiSource"] = "fallback"
        return data

    score_value = float(risk.get("score", 0.0) or 0.0)
    label = str(risk.get("label") or "Medium")
    risk["aiExplanation"] = _to_plain_language_risk_text(
        symbol=symbol,
        score=score_value,
        label=label,
        text=(
            f"{symbol.upper()} has a Risk Score of {score_value:.1f} out of 5 ({label}). "
            "Risk is not very low right now, so it is better to invest slowly and watch news and price moves."
        ),
        high_hint=high_hint,
    )
    risk["aiSource"] = "fallback"
    return data


def _to_plain_language_risk_text(symbol: str, score: float, label: str, text: str, high_hint: str | None = None) -> str:
    simplified = " ".join(str(text or "").split())
    replacements = {
        r"\bsetup\b": "overall picture",
        r"\bposition sizing\b": "how much money to put",
        r"\ballocation\b": "money split",
        r"\bconviction\b": "confidence",
        r"\bdrawdown\b": "price fall",
        r"\bvolatility\b": "price ups and downs",
        r"\bmomentum\b": "recent price trend",
        r"\bfinancialRisk\b": "financial risk",
        r"\bnarrativeRisk\b": "news risk",
        r"\btechnicalRisk\b": "price trend risk",
        r"\bsentiment\b": "market mood",
        r"\bbullish\b": "positive",
        r"\bbearish\b": "weak",
    }
    for pattern, target in replacements.items():
        simplified = re.sub(pattern, target, simplified, flags=re.IGNORECASE)

    if "risk score" not in simplified.lower():
        simplified = (
            f"{symbol.upper()} has a Risk Score of {score:.1f} out of 5 ({label}). "
            f"{simplified}"
        ).strip()

    if len(simplified) > 220:
        chunks = re.split(r"(?<=[.!?])\s+", simplified)
        simplified = " ".join(chunks[:2]).strip()

    if not re.search(r"\b(invest slowly|careful|risk|watch)\b", simplified, flags=re.IGNORECASE):
        hint = (high_hint or "technicalRisk").replace("technicalRisk", "price trend risk")
        hint = hint.replace("narrativeRisk", "news risk").replace("financialRisk", "financial risk")
        base = simplified.strip()
        if base and base[-1] not in ".!?":
            base += "."
        simplified = f"{base} The main risk now is {hint}, so invest slowly."
    return simplified


@router.get("/search")
async def search_stocks(q: str = Query("", min_length=0, max_length=50)) -> dict:
    return {"results": await dashboard_service.search_stocks(q)}

@router.get("/ticker")
async def get_ticker(
    symbols: str = Query("", max_length=5000),
    refresh: bool = Query(False),
) -> dict:
    symbol_list = [item.strip().upper() for item in symbols.split(",") if item.strip()] if symbols else []
    key_part = ",".join(symbol_list) if symbol_list else "default"
    cache_key = f"ticker:{key_part}"
    cached = await redis_cache.get_json(cache_key)
    if cached:
        # If refreshing, check if the data is at least 10 seconds old to prevent hammering
        if not refresh:
            return {"cached": True, "data": cached}
        # For simplicity, we can just check if it exists and return it unless we really want fresh data
        # but here we'll just always return cached if it's there and not 'refresh'
        # To truly fix 'lag', we'll return cached even if refresh=True for the first 10 seconds.
        return {"cached": True, "data": cached}

    try:
        data = await dashboard_service.get_ticker_tape(symbol_list or None)
        await redis_cache.set_json(cache_key, data, ttl_seconds=15)
        return {"cached": False, "data": data}
    except Exception:
        if cached:
            return {"cached": True, "stale": True, "data": cached}
        raise

@router.get("/index-heatmap")
async def get_index_heatmap(
    index: str = Query("NIFTY 50", min_length=1, max_length=80),
    refresh: bool = Query(False),
) -> dict:
    normalized = index.strip() or "NIFTY 50"
    cache_key = f"index-heatmap:{normalized.upper()}"
    stale_key = f"index-heatmap:last:{normalized.upper()}"
    cached = await redis_cache.get_json(cache_key) if not refresh else None
    if not cached and refresh:
        cached = await redis_cache.get_json(cache_key)
    
    if cached:
        return {"cached": True, **cached}

    payload = await dashboard_service.get_index_heatmap(normalized)
    rows = payload.get("rows") if isinstance(payload, dict) else []
    if rows:
        await redis_cache.set_json(cache_key, payload, ttl_seconds=30)
        await redis_cache.set_json(stale_key, payload, ttl_seconds=60 * 60 * 24 * 7)
        return {"cached": False, **payload}

    stale = await redis_cache.get_json(stale_key)
    if stale:
        return {"cached": True, "stale": True, **stale}
    return {"cached": False, **payload}


@router.get("/market-news")
async def get_market_news(refresh: bool = Query(False)) -> dict:
    today = datetime.now(IST).date().isoformat()
    cache_key = "market-news:latest"
    stale_key = "market-news:last"
    cached = await redis_cache.get_json(cache_key) if not refresh else None
    if isinstance(cached, dict):
        cached_date = str(cached.get("date") or "")
        cached_rows = cached.get("items") if isinstance(cached.get("items"), list) else []
        fetched_at_raw = str(cached.get("fetchedAt") or "")
        fetched_at = None
        if fetched_at_raw:
            try:
                fetched_at = datetime.fromisoformat(fetched_at_raw)
            except Exception:
                fetched_at = None
        age_seconds = (datetime.now(IST) - fetched_at).total_seconds() if fetched_at else 0
        if cached_rows and cached_date == today:
            if age_seconds > 600:
                asyncio.create_task(_refresh_market_news_cache(today, cache_key, stale_key))
            return {"cached": True, "date": cached_date, "data": cached_rows}
        if cached_rows:
            asyncio.create_task(_refresh_market_news_cache(today, cache_key, stale_key))
            return {"cached": True, "stale": True, "date": cached_date, "data": cached_rows}

    stale = await redis_cache.get_json(stale_key)
    if not refresh and isinstance(stale, dict):
        stale_rows = stale.get("items") if isinstance(stale.get("items"), list) else []
        stale_date = str(stale.get("date") or today)
        if stale_rows:
            asyncio.create_task(_refresh_market_news_cache(today, cache_key, stale_key))
            return {"cached": True, "stale": True, "date": stale_date, "data": stale_rows}

    data = await dashboard_service.get_market_news()
    if data:
        payload = {"date": today, "items": data, "fetchedAt": datetime.now(IST).isoformat()}
        await redis_cache.set_json(cache_key, payload, ttl_seconds=60 * 60 * 30)
        await redis_cache.set_json(stale_key, payload, ttl_seconds=60 * 60 * 24 * 7)
        return {"cached": False, "date": today, "data": data}

    if isinstance(cached, dict):
        fallback_rows = cached.get("items") if isinstance(cached.get("items"), list) else []
        fallback_date = str(cached.get("date") or today)
        if fallback_rows:
            return {"cached": True, "date": fallback_date, "data": fallback_rows}

    if isinstance(stale, dict):
        stale_rows = stale.get("items") if isinstance(stale.get("items"), list) else []
        stale_date = str(stale.get("date") or today)
        if stale_rows:
            return {"cached": True, "stale": True, "date": stale_date, "data": stale_rows}

    return {"cached": False, "date": today, "data": []}


INDIAN_SECTORS = [
    "Technology", "Financial Services", "Healthcare", "Consumer Cyclical",
    "Consumer Defensive", "Industrials", "Basic Materials", "Energy",
    "Communication Services", "Utilities", "Real Estate",
]


@router.get("/screener")
async def stock_screener(
    exchange: str = Query("NSE"),
    sector: str = Query(""),
    industry: str = Query(""),
    market_cap_min: float = Query(0),
    market_cap_max: float = Query(0),
    pe_min: float = Query(0),
    pe_max: float = Query(0),
    price_min: float = Query(0),
    price_max: float = Query(0),
    dividend_min: float = Query(0),
    volume_min: float = Query(0),
    limit: int = Query(100, ge=1, le=500),
) -> dict:
    param_str = f"{exchange}:{sector}:{industry}:{market_cap_min}:{market_cap_max}:{pe_min}:{pe_max}:{price_min}:{price_max}:{dividend_min}:{volume_min}:{limit}"
    param_hash = hashlib.md5(param_str.encode()).hexdigest()
    cache_key = f"screener:v4:{param_hash}"

    cached = await redis_cache.get_json(cache_key)
    if cached and cached.get("results"):
        return {"results": cached.get("results", []), "count": cached.get("count", 0), "cached": True}

    try:
        results = await dashboard_service.screen_stocks(
            exchange=exchange,
            sector=sector,
            industry=industry,
            market_cap_min=market_cap_min,
            market_cap_max=market_cap_max,
            price_min=price_min,
            price_max=price_max,
            volume_min=volume_min,
            dividend_min=dividend_min,
            limit=limit,
        )

        # Post-filter by PE and Dividend if requested
        if pe_min > 0 or pe_max > 0 or dividend_min > 0:
            filtered = []
            for item in results:
                if pe_min > 0 or pe_max > 0:
                    pe = item.get("pe")
                    if pe is None:
                        continue
                    if pe_min > 0 and pe < pe_min:
                        continue
                    if pe_max > 0 and pe > pe_max:
                        continue
                if dividend_min > 0:
                    div = item.get("dividendYield")
                    if div is None or div < dividend_min:
                        continue
                filtered.append(item)
            results = filtered

        payload = {"results": results, "count": len(results)}
        if results:
            await redis_cache.set_json(cache_key, payload, ttl_seconds=300)
        return {"results": results, "count": len(results), "cached": False}
    except Exception as exc:
        if cached:
            return {"results": cached.get("results", []), "count": cached.get("count", 0), "cached": True}
        raise HTTPException(status_code=502, detail=f"Screener data unavailable: {str(exc)}")


@router.get("/screener/sectors")
async def get_screener_sectors() -> dict:
    cache_key = "screener:sectors"
    cached = await redis_cache.get_json(cache_key)
    if cached:
        return {"sectors": cached, "cached": True}

    # Return hardcoded Indian market sectors (covers FMP sector taxonomy for Indian stocks)
    await redis_cache.set_json(cache_key, INDIAN_SECTORS, ttl_seconds=60 * 60 * 24)
    return {"sectors": INDIAN_SECTORS, "cached": False}


@router.get("/ipo/{symbol}/ai-analysis")
async def get_ipo_ai_analysis(symbol: str) -> dict:
    cache_key = f"ipo_ai:{symbol.upper()}"
    cached = await redis_cache.get_json(cache_key)
    if cached:
        return {"symbol": symbol.upper(), "cached": True, **cached}

    # Fetch IPO context from calendar
    from app.services.providers import MarketDataProviders as _Providers
    _providers = _Providers()
    today = datetime.now(IST).date()
    from_date = (today - timedelta(days=180)).isoformat()
    to_date = (today + timedelta(days=180)).isoformat()
    ipo_list = await _providers.get_ipo_calendar(from_date=from_date, to_date=to_date)
    ipo_data = next((i for i in ipo_list if str(i.get("symbol", "")).upper() == symbol.upper()), {})
    company = ipo_data.get("company") or symbol

    try:
        analysis = await asyncio.wait_for(
            ai_adapter.generate_ipo_analysis(symbol=symbol, company=company, ipo_data=ipo_data),
            timeout=15,
        )
    except Exception:
        analysis = await ai_adapter.generate_ipo_analysis(symbol=symbol, company=company, ipo_data=ipo_data)

    await redis_cache.set_json(cache_key, analysis, ttl_seconds=3600)
    return {"symbol": symbol.upper(), "cached": False, **analysis}


@router.get("/ipo")
async def get_ipo_data(type: str = Query("upcoming")) -> dict:
    from app.services.providers import MarketDataProviders
    providers = MarketDataProviders()
    today = datetime.now(IST).date()
    cache_key = f"ipo:{type}:{today.isoformat()}"

    cached = await redis_cache.get_json(cache_key)
    if cached:
        return {"type": type, "data": cached, "cached": True}

    try:
        if type == "recent":
            data = await providers.get_ipo_recent()
        else:
            from_date = today.isoformat()
            to_date = (today + timedelta(days=90)).isoformat()
            data = await providers.get_ipo_calendar(from_date=from_date, to_date=to_date)
        await redis_cache.set_json(cache_key, data, ttl_seconds=1800)
        return {"type": type, "data": data, "cached": False}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"IPO data unavailable: {str(exc)}")


class AIScreenerRequest(BaseModel):
    query: str

@router.post("/screener/ai")
async def ai_stock_screener(payload: AIScreenerRequest) -> dict:
    """Natural language screener — converts query to filter params via Gemini, then runs screener."""
    query = (payload.query or "").strip()
    if not query:
        raise HTTPException(status_code=422, detail="Query is required")

    # Parse NL → screener params
    params = await ai_adapter.parse_screener_query(query)

    exchange = str(params.get("exchange", "NSE"))
    sector = str(params.get("sector", ""))
    market_cap_min = float(params.get("market_cap_min", 0) or 0)
    market_cap_max = float(params.get("market_cap_max", 0) or 0)
    pe_min = float(params.get("pe_min", 0) or 0)
    pe_max = float(params.get("pe_max", 0) or 0)
    price_min = float(params.get("price_min", 0) or 0)
    price_max = float(params.get("price_max", 0) or 0)
    dividend_min = float(params.get("dividend_min", 0) or 0)
    volume_min = float(params.get("volume_min", 0) or 0)
    limit = int(params.get("limit", 50) or 50)

    try:
        results = await dashboard_service.screen_stocks(
            exchange=exchange, sector=sector, industry="",
            market_cap_min=market_cap_min, market_cap_max=market_cap_max,
            price_min=price_min, price_max=price_max,
            volume_min=volume_min, dividend_min=dividend_min, limit=limit,
        )
        if pe_min > 0 or pe_max > 0 or dividend_min > 0:
            filtered = []
            for r in results:
                if pe_min > 0 or pe_max > 0:
                    if r.get("pe") is None:
                        continue
                    if pe_min > 0 and r["pe"] < pe_min:
                        continue
                    if pe_max > 0 and r["pe"] > pe_max:
                        continue
                if dividend_min > 0:
                    div = r.get("dividendYield")
                    if div is None or div < dividend_min:
                        continue
                filtered.append(r)
            results = filtered
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Screener error: {exc}")

    return {
        "query": query,
        "parsedFilters": params,
        "results": results,
        "count": len(results),
    }


class PortfolioHolding(BaseModel):
    symbol: str
    quantity: float
    buyPrice: float
    currentPrice: float | None = None
    sector: str | None = None
    beta: float | None = None

class PortfolioRiskRequest(BaseModel):
    holdings: list[PortfolioHolding]

@router.post("/portfolio-risk")
async def portfolio_risk_assessment(payload: PortfolioRiskRequest) -> dict:
    """AI-powered portfolio risk and correlation analysis."""
    if not payload.holdings:
        raise HTTPException(status_code=422, detail="At least one holding is required")

    # Build enriched holdings list
    total_invested = sum(h.quantity * h.buyPrice for h in payload.holdings)
    total_current = sum(
        h.quantity * (h.currentPrice or h.buyPrice) for h in payload.holdings
    )
    denom = total_current if total_current > 0 else total_invested

    enriched = [
        {
            "symbol": h.symbol.upper(),
            "investedValue": round(h.quantity * h.buyPrice, 2),
            "currentValue": round(h.quantity * (h.currentPrice or h.buyPrice), 2),
            "weight": round((h.quantity * (h.currentPrice or h.buyPrice)) / denom * 100, 1) if denom > 0 else 0,
            "sector": h.sector or "Unknown",
            "beta": h.beta,
        }
        for h in payload.holdings
    ]

    analysis = await ai_adapter.analyze_portfolio_risk(enriched, [])
    return {
        "totalInvested": round(total_invested, 2),
        "totalCurrentValue": round(total_current, 2),
        "totalPnl": round(total_current - total_invested, 2),
        "holdingCount": len(payload.holdings),
        "analysis": analysis,
    }


class PortfolioRoastHolding(BaseModel):
    symbol: str
    quantity: float
    avgPrice: float
    currentValue: float | None = None
    pnl: float | None = None

class PortfolioRoastRequest(BaseModel):
    holdings: list[PortfolioRoastHolding]
    totalValue: float | None = None

@router.post("/portfolio-roast")
async def portfolio_roast(payload: PortfolioRoastRequest) -> dict:
    """AI 'Portfolio Doctor' — roast + grade + actionable fixes for uploaded holdings."""
    if not payload.holdings:
        raise HTTPException(status_code=422, detail="No holdings provided")
    total = payload.totalValue or sum(h.currentValue or (h.quantity * h.avgPrice) for h in payload.holdings)
    holdings_dicts = [
        {
            "symbol": h.symbol.upper(),
            "quantity": h.quantity,
            "avgPrice": h.avgPrice,
            "currentValue": round(h.currentValue or h.quantity * h.avgPrice, 2),
            "pnl": round(h.pnl or (h.currentValue or 0) - (h.quantity * h.avgPrice), 2),
        }
        for h in payload.holdings
    ]
    result = await ai_adapter.roast_portfolio(holdings_dicts, total)
    return {"holdings": len(payload.holdings), "totalValue": round(total, 2), "roast": result}


@router.get("/{symbol}/competitor-verdict")
async def competitor_verdict(symbol: str) -> dict:
    """AI verdict on which stock wins among sector peers right now."""
    cache_key = f"comp_verdict:{symbol.upper()}"
    cached = await redis_cache.get_json(cache_key)
    if cached:
        return {"symbol": symbol.upper(), "cached": True, **cached}
    try:
        dashboard = await dashboard_service.get_dashboard(symbol=symbol)
        metrics = dashboard.get("metrics", {}) if isinstance(dashboard, dict) else {}
        competitors = (dashboard.get("competitors", {}) or {}) if isinstance(dashboard, dict) else {}
        peers = competitors.get("table", []) or []
        verdict = await ai_adapter.generate_competitor_verdict(
            symbol=symbol, stock_metrics=metrics, peers=peers
        )
        await redis_cache.set_json(cache_key, verdict, ttl_seconds=3600)
        return {"symbol": symbol.upper(), "cached": False, **verdict}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Competitor verdict unavailable: {exc}")


@router.get("/{symbol}/earnings-tldr")
async def earnings_tldr(symbol: str) -> dict:
    """AI TL;DR of recent quarterly earnings — 4 bullets + CEO signal."""
    cache_key = f"earnings_tldr:{symbol.upper()}"
    cached = await redis_cache.get_json(cache_key)
    if cached:
        return {"symbol": symbol.upper(), "cached": True, **cached}
    try:
        dashboard = await dashboard_service.get_dashboard(symbol=symbol)
        financials = (dashboard.get("financials", {}) or {}) if isinstance(dashboard, dict) else {}
        quarterly = (
            financials.get("quarterlyConsolidated")
            or financials.get("quarterlyStandalone")
            or financials.get("quarterly")
            or []
        )
        company_name = str(dashboard.get("companyName", symbol)) if isinstance(dashboard, dict) else symbol
        tldr = await ai_adapter.generate_earnings_tldr(
            symbol=symbol, quarterly_data=quarterly, company_name=company_name
        )
        await redis_cache.set_json(cache_key, tldr, ttl_seconds=7200)
        return {"symbol": symbol.upper(), "cached": False, **tldr}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Earnings TL;DR unavailable: {exc}")


@router.get("/{symbol}/swot")
async def get_swot_analysis(symbol: str, refresh: bool = False) -> dict:
    import time as _time
    cache_key = f"swot:{symbol.upper()}"

    if not refresh:
        cached = await redis_cache.get_json(cache_key)
        if cached:
            return {"symbol": symbol.upper(), "cached": True, **cached}

    # Fetch fresh dashboard context for AI analysis
    context: dict = {"symbol": symbol.upper()}
    try:
        context = await asyncio.wait_for(dashboard_service.get_dashboard(symbol=symbol), timeout=20)
    except Exception:
        context = {"symbol": symbol.upper()}

    try:
        swot = await asyncio.wait_for(ai_adapter.generate_swot(symbol=symbol, context=context), timeout=15)
    except Exception:
        swot = ai_adapter._fallback_swot(symbol=symbol, context=context)

    source = "gemini" if bool(str(settings.gemini_api_key or "").strip()) else "fallback"
    result = {**swot, "source": source, "generatedAt": int(_time.time())}
    await redis_cache.set_json(cache_key, result, ttl_seconds=60 * 60)
    return {"symbol": symbol.upper(), "cached": False, **result}


@router.get("/{symbol}/dashboard")
async def get_stock_dashboard(
    symbol: str,
    timeframe: str = Query("5Y"),
    refresh: bool = Query(False),
    exchange: str = Query("NSE"),
) -> dict:
    normalized_exchange = str(exchange or "NSE").strip().upper()
    cache_key = f"dashboard:{symbol.upper()}:{timeframe}:{normalized_exchange}"
    stale_key = f"dashboard:last:{symbol.upper()}:{timeframe}:{normalized_exchange}"
    cached = await redis_cache.get_json(cache_key) if not refresh else None
    if cached:
        cached = await _enrich_score_explanations(symbol=symbol, data=cached, allow_gemini=False)
        if _dashboard_needs_ai_refresh(cached):
            asyncio.create_task(_refresh_dashboard_cache(symbol=symbol, timeframe=timeframe, cache_key=cache_key, stale_key=stale_key, exchange=normalized_exchange))
        await redis_cache.set_json(cache_key, cached, ttl_seconds=settings.cache_ttl_seconds)
        await redis_cache.set_json(stale_key, cached, ttl_seconds=60 * 60 * 24 * 7)
        return {"cached": True, "data": cached}

    try:
        data = await asyncio.wait_for(dashboard_service.get_dashboard(symbol=symbol, timeframe=timeframe, exchange=normalized_exchange), timeout=12)
        data = await _enrich_score_explanations(symbol=symbol, data=data, allow_gemini=False)
        await redis_cache.set_json(cache_key, data, ttl_seconds=settings.cache_ttl_seconds)
        await redis_cache.set_json(stale_key, data, ttl_seconds=60 * 60 * 24 * 7)
        if bool(str(settings.gemini_api_key or "").strip()):
            asyncio.create_task(_refresh_dashboard_cache(symbol=symbol, timeframe=timeframe, cache_key=cache_key, stale_key=stale_key, exchange=normalized_exchange))
        return {"cached": False, "data": data}
    except Exception as exc:
        stale = await redis_cache.get_json(stale_key)
        if stale:
            asyncio.create_task(_refresh_dashboard_cache(symbol=symbol, timeframe=timeframe, cache_key=cache_key, stale_key=stale_key, exchange=normalized_exchange))
            return {"cached": True, "stale": True, "data": stale}
        asyncio.create_task(_refresh_dashboard_cache(symbol=symbol, timeframe=timeframe, cache_key=cache_key, stale_key=stale_key, exchange=normalized_exchange))
        fallback = get_sample_dashboard(symbol=symbol)
        fallback["timeframe"] = timeframe
        fallback = await _enrich_score_explanations(symbol=symbol, data=fallback, allow_gemini=False)
        await redis_cache.set_json(stale_key, fallback, ttl_seconds=60 * 30)
        return {
            "cached": True,
            "stale": True,
            "fallback": True,
            "warning": "Live dashboard data timed out. Showing fallback data.",
            "data": fallback,
        }


@router.post("/{symbol}/chat", response_model=ChatResponse)
async def chat_with_ai(symbol: str, payload: ChatRequest) -> ChatResponse:
    dashboard = await dashboard_service.get_dashboard(symbol=symbol)
    answer, source = await ai_adapter.chat(symbol=symbol, question=payload.question, context=dashboard)
    return ChatResponse(answer=answer, source=source)


@router.get("/{symbol}/watchlist-analysis", response_model=ChatResponse)
async def get_watchlist_analysis(symbol: str) -> ChatResponse:
    cache_key = f"watchlist-analysis:{symbol.upper()}"
    cached = await redis_cache.get_json(cache_key)
    if isinstance(cached, dict):
        return ChatResponse(
            answer=str(cached.get("answer") or "No response."),
            source=str(cached.get("source") or "fallback"),
        )

    try:
        dashboard = await asyncio.wait_for(dashboard_service.get_dashboard(symbol=symbol), timeout=20)
    except Exception:
        dashboard = get_sample_dashboard(symbol=symbol)

    answer, source = await ai_adapter.generate_watchlist_review(symbol=symbol, context=dashboard)
    payload = {"answer": answer, "source": source}
    await redis_cache.set_json(cache_key, payload, ttl_seconds=60 * 30)
    return ChatResponse(answer=answer, source=source)


@router.post("/compare-analysis", response_model=ChatResponse)
async def get_compare_analysis(payload: CompareAnalysisRequest) -> ChatResponse:
    symbol_a = payload.symbol_a.strip().upper()
    symbol_b = payload.symbol_b.strip().upper()
    if not symbol_a or not symbol_b:
        raise HTTPException(status_code=422, detail="Both symbols are required")
    if symbol_a == symbol_b:
        raise HTTPException(status_code=422, detail="Choose two different symbols")

    cache_key = f"compare-analysis:{symbol_a}:{symbol_b}"
    cached = await redis_cache.get_json(cache_key)
    if isinstance(cached, dict):
        return ChatResponse(
            answer=str(cached.get("answer") or "No response."),
            source=str(cached.get("source") or "fallback"),
        )

    async def load_context(sym: str) -> dict:
        try:
            return await asyncio.wait_for(dashboard_service.get_dashboard(symbol=sym), timeout=20)
        except Exception:
            return get_sample_dashboard(symbol=sym)

    context_a, context_b = await asyncio.gather(load_context(symbol_a), load_context(symbol_b))
    answer, source = await ai_adapter.generate_compare_analysis(
        symbol_a=symbol_a,
        symbol_b=symbol_b,
        context_a=context_a,
        context_b=context_b,
    )
    response_payload = {"answer": answer, "source": source}
    await redis_cache.set_json(cache_key, response_payload, ttl_seconds=60 * 30)
    return ChatResponse(answer=answer, source=source)


@router.post("/{symbol}/news-analysis", response_model=NewsAnalysisResponse)
async def analyze_news_item(symbol: str, payload: NewsAnalysisRequest) -> NewsAnalysisResponse:
    context: dict = {"symbol": symbol.upper()}
    try:
        context = await asyncio.wait_for(dashboard_service.get_dashboard(symbol=symbol), timeout=20)
    except Exception:
        context = {"symbol": symbol.upper()}

    analysis, source = await ai_adapter.analyze_news(
        symbol=symbol,
        article={
            "title": payload.title,
            "summary": payload.summary,
            "source": payload.source,
            "publishedAt": payload.published_at,
            "sentimentScore": payload.sentiment_score,
        },
        context=context,
    )
    return NewsAnalysisResponse(source=source, **analysis)


@router.get("/{symbol}/research-report", response_model=ReportResponse)
async def get_research_report(symbol: str) -> ReportResponse:
    dashboard = await dashboard_service.get_dashboard(symbol=symbol)
    report = await ai_adapter.generate_report(symbol=symbol, context=dashboard)
    return ReportResponse(symbol=symbol.upper(), report_markdown=report)


@router.get("/{symbol}/returns-projection")
async def get_returns_projection(
    symbol: str,
    amount: float = Query(..., gt=0),
    cagr: float = Query(..., ge=0, le=100),
    years: int = Query(..., ge=1, le=40),
) -> dict:
    points = []
    for year in range(0, years + 1):
        value = amount * ((1 + cagr / 100) ** year)
        points.append({"year": year, "value": round(value, 2)})
    return {
        "symbol": symbol.upper(),
        "amount": amount,
        "cagr": cagr,
        "years": years,
        "futureValue": points[-1]["value"],
        "series": points,
    }


@router.get("/{symbol}/health-check")
async def stock_health(symbol: str) -> dict:
    if not symbol.strip():
        raise HTTPException(status_code=400, detail="Invalid symbol")
    return {"symbol": symbol.upper(), "status": "ok"}
